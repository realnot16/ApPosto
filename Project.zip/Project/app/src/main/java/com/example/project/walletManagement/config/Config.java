package com.example.project.walletManagement.config;

public class Config {
    public static final String PAYPAL_CLIENT_ID="AQrI3OWZWv0XAnfHpWIRB1mbfP2URXGxGhWvb0oDPdrHSBsAkm0iOCtblVI36Rqbqq3caoUJi7Yo7Nqc";
}
