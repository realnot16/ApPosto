package com.example.project.ParametersAsync;

public class WalletChargeParamsAsync {

    }
