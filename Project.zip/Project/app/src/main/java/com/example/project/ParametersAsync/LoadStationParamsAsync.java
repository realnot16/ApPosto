package com.example.project.ParametersAsync;

public class LoadStationParamsAsync {
    public double latitude;
    public double longitude;
    public LoadStationParamsAsync(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }


}
